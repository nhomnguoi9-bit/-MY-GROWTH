# MY GROWTH – Android project

This is the Android Studio source project for the MY GROWTH dark-mode study planner.

## Included
- Weekly plan: reading, English, brain/cognition, critical thinking and logic review.
- Daily completion checkbox saved locally on the device.
- Daily reminder scheduled for approximately 21:15 local time.
- Reminder is rescheduled after reboot.
- Dark visual theme.

## Build an APK
1. Install Android Studio (with Android SDK Platform 35).
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `MYGrowthAndroid` folder.
4. Allow Gradle sync to finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the APK location; copy it to your phone and install it.
7. On first launch, allow notifications. Also allow background/autostart if your phone's battery settings restrict the app.

## Notes
- This deliverable is Android source code, not a precompiled APK. This environment does not have the Android SDK/Gradle build tools needed to compile and sign an APK here.
- The reminder uses Android's inexact idle-friendly alarm API, so delivery may be a little later than 21:15 depending on Android power management.
- The reminder time is currently set to 21:15 in `ReminderScheduler`. Change it in `StudyReminderReceiver.kt` if needed.
- Data is stored locally on the phone; there is no account or cloud sync in this starter version.
