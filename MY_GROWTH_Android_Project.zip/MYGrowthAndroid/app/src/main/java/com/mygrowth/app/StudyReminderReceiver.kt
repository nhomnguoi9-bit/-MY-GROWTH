package com.mygrowth.app

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

class StudyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        ReminderScheduler.createChannel(context)
        val day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val item = MainActivity.plan[day] ?: ("Phát triển bản thân" to "Dành 60 phút cho mục tiêu hôm nay")
        val open = PendingIntent.getActivity(
            context, 100, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, ReminderScheduler.CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Đến giờ học rồi!")
            .setContentText("${item.first} – ${item.second}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("${item.first}\n${item.second}\nBắt đầu với 60 phút tập trung nhé!"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            manager.notify(7, notification)
        }
        ReminderScheduler.scheduleNext(context)
    }
}

object ReminderScheduler {
    const val CHANNEL = "my_growth_study"
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Nhắc học MY GROWTH", NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "Nhắc bạn học nội dung phát triển bản thân mỗi tối"
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }
    fun scheduleNext(context: Context) {
        val intent = Intent(context, StudyReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, 21, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 21); set(Calendar.MINUTE, 15); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.scheduleNext(context)
    }
}
