package com.mygrowth.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 16, 26)
    private val panel = Color.rgb(24, 31, 46)
    private val white = Color.rgb(238, 242, 250)
    private val muted = Color.rgb(155, 168, 190)
    private val green = Color.rgb(89, 210, 154)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
        ReminderScheduler.scheduleNext(this)
        render()
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 34, 24, 32)
        }
        scroll.addView(page)

        page.addView(TextView(this).apply {
            text = "MY GROWTH"
            textSize = 28f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        page.addView(TextView(this).apply {
            text = "Mỗi ngày tốt hơn 1%  •  Hành trình phát triển bản thân"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, 6, 0, 24)
        })

        val today = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK)
        val todayPlan = plan[today] ?: plan[java.util.Calendar.MONDAY]!!
        page.addView(section("HÔM NAY"))
        page.addView(card("${todayPlan.first}  ${todayPlan.second}", "Buổi học gợi ý: 60 phút • Sau khi tập gym"))
        page.addView(section("THỜI KHÓA BIỂU TUẦN"))
        val days = listOf(
            java.util.Calendar.MONDAY to "Thứ 2",
            java.util.Calendar.TUESDAY to "Thứ 3",
            java.util.Calendar.WEDNESDAY to "Thứ 4",
            java.util.Calendar.THURSDAY to "Thứ 5",
            java.util.Calendar.FRIDAY to "Thứ 6",
            java.util.Calendar.SATURDAY to "Thứ 7",
            java.util.Calendar.SUNDAY to "Chủ nhật"
        )
        days.forEach { (day, label) ->
            val p = plan[day]!!
            page.addView(card("$label  •  ${p.first}", p.second))
        }

        page.addView(section("NHẮC NHỞ"))
        page.addView(TextView(this).apply {
            text = "Ứng dụng nhắc học vào khoảng 21:15 mỗi tối. Thông báo có thể đến trễ vài phút tùy chế độ tiết kiệm pin của điện thoại."
            textSize = 13f
            setTextColor(muted)
            setPadding(4, 4, 4, 12)
        })
        val done = getSharedPreferences("progress", Context.MODE_PRIVATE)
        val check = CheckBox(this).apply {
            text = "Đánh dấu đã hoàn thành buổi học hôm nay"
            setTextColor(white)
            buttonTintList = android.content.res.ColorStateList.valueOf(green)
            isChecked = done.getBoolean(java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date()), false)
            setOnCheckedChangeListener { _, checked ->
                done.edit().putBoolean(java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date()), checked).apply()
                Toast.makeText(this@MainActivity, if (checked) "Đã ghi nhận tiến độ!" else "Đã bỏ đánh dấu", Toast.LENGTH_SHORT).show()
            }
        }
        page.addView(check)
        page.addView(TextView(this).apply {
            text = "Cách học 60 phút: 10 phút ôn lại • 30 phút kiến thức mới • 15 phút thực hành • 5 phút ghi chú."
            textSize = 13f
            setTextColor(muted)
            setPadding(0, 18, 0, 0)
        })
        setContentView(scroll)
    }

    private fun section(s: String) = TextView(this).apply {
        text = s
        textSize = 12f
        setTextColor(green)
        setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(2, 22, 0, 10)
    }

    private fun card(title: String, subtitle: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 15, 16, 15)
            setBackgroundColor(panel)
            val t = TextView(this@MainActivity).apply {
                text = title; textSize = 16f; setTextColor(white)
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val s = TextView(this@MainActivity).apply {
                text = subtitle; textSize = 13f; setTextColor(muted); setPadding(0, 5, 0, 0)
            }
            addView(t); addView(s)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 9
            layoutParams = lp
        }
    }

    companion object {
        val plan = mapOf(
            java.util.Calendar.MONDAY to ("Đọc sách" to "Đọc hiểu, mở rộng vốn từ và cách diễn đạt"),
            java.util.Calendar.TUESDAY to ("Học tiếng Anh" to "Từ vựng, ngữ pháp, nghe và nói căn bản"),
            java.util.Calendar.WEDNESDAY to ("Tư duy và bộ não" to "Neuron, trí nhớ, sự tập trung và cách não hoạt động"),
            java.util.Calendar.THURSDAY to ("Tư duy phản biện" to "Phân tích vấn đề, kiểm tra bằng chứng và lập luận"),
            java.util.Calendar.FRIDAY to ("Đọc sách" to "Đọc và ghi lại 3 ý quan trọng"),
            java.util.Calendar.SATURDAY to ("Học tiếng Anh" to "Ôn tập và luyện bài thực hành"),
            java.util.Calendar.SUNDAY to ("Ôn tư duy & logic" to "Ôn nguyên nhân-kết quả, lập luận và phản biện")
        )
    }
}
